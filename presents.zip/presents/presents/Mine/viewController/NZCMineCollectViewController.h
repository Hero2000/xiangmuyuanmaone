//
//  NZCMineCollectViewController.h
//  presents
//
//  Created by dllo on 16/1/12.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NZCMineCollectViewController : UIViewController


@end
