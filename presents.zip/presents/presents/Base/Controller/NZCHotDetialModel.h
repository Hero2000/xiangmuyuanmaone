//
//  NZCHotDetialModel.h
//  presents
//
//  Created by dllo on 16/1/7.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import "BaseModel.h"

@interface NZCHotDetialModel : BaseModel

@property (nonatomic, strong) NSString *content;

@property (nonatomic, strong) NSDictionary *user;

@end
