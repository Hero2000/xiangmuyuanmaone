//
//  CarsouselModel.h
//  presents
//
//  Created by dapeng on 16/1/7.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CarsouselModel : BaseModel
@property (nonatomic, copy) NSString *image_url;
@property (nonatomic, copy) NSString *target_id;
@property (nonatomic, copy) NSString *target;
@property (nonatomic, copy) NSString *target_url;
@end
