//
//  CarsouselModel.m
//  presents
//
//  Created by dapeng on 16/1/7.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import "CarsouselModel.h"

@implementation CarsouselModel

@end
