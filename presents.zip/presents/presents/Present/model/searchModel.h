//
//  searchModel.h
//  presents
//
//  Created by dapeng on 16/1/9.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface searchModel : BaseModel
@property (nonatomic, copy) NSString *hot_words;
@property (nonatomic, copy) NSString *placeholder;
@end
