//
//  SAPChannelsModel.h
//  presents
//
//  Created by dapeng on 16/1/10.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SAPChannelsModel : BaseModel
@property (nonatomic, copy) NSString *name;
@end
