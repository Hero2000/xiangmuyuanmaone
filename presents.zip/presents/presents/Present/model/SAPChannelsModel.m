//
//  SAPChannelsModel.m
//  presents
//
//  Created by dapeng on 16/1/10.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import "SAPChannelsModel.h"

@implementation SAPChannelsModel

@end
