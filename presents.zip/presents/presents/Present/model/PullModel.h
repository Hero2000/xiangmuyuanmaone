//
//  PullModel.h
//  presents
//
//  Created by dapeng on 16/1/11.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PullModel : BaseModel
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *id;
@end
