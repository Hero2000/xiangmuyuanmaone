//
//  NoneIdViewController.h
//  presents
//
//  Created by dapeng on 16/1/8.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoneIdViewController : UIViewController
@property (nonatomic, copy) NSString *imageUrl;
@end
