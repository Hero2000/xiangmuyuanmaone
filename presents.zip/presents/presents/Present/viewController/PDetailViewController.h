//
//  PDetailViewController.h
//  presents
//
//  Created by dapeng on 16/1/8.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PDetailViewController : UIViewController
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *cover_image_url;
@property (nonatomic, copy) NSString *titles;
@end
