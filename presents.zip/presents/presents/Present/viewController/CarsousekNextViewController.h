//
//  CarsousekNextViewController.h
//  presents
//
//  Created by dapeng on 16/1/8.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface CarsousekNextViewController : UIViewController
@property (nonatomic, copy) NSString *titles;
@property (nonatomic, copy) NSString *cover_image_url;
@property (nonatomic, copy) NSString *ids;
@property (nonatomic, copy) NSString *NavTitle;
@end
