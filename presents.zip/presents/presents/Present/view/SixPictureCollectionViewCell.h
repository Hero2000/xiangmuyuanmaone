//
//  SixPictureCollectionViewCell.h
//  presents
//
//  Created by dapeng on 16/1/10.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SixPictureCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) PresentMdoel *presentModel;
@property (nonatomic, strong) UIImageView *images;
@end
