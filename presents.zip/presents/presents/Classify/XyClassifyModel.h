//
//  XyClassifyModel.h
//  presents
//
//  Created by Xy on 16/1/8.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import "BaseModel.h"

@interface XyClassifyModel : BaseModel

@property (copy, nonatomic) NSString *banner_image_url;
@property (copy, nonatomic) NSString *next_url;

@end
