//
//  WholeModel.h
//  presents
//
//  Created by Xy on 16/1/13.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import "BaseModel.h"

@interface WholeModel : BaseModel
@property (nonatomic, copy) NSString *cover_image_url;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, copy) NSString *title;

@end
