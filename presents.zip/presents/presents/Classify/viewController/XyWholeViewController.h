//
//  XyWholeViewController.h
//  presents
//
//  Created by Xy on 16/1/13.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import "BaseViewController.h"

@interface XyWholeViewController : BaseViewController

@end
