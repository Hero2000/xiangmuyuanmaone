//
//  XyGiftTableViewCell.h
//  presents
//
//  Created by Xy on 16/1/9.
//  Copyright © 2016年 Xy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XyGiftModel.h"

@interface XyLinkageTableViewCell : UITableViewCell
@property (strong, nonatomic) UILabel *name;
@property (strong, nonatomic) UIView *views;
@property (strong, nonatomic) UIView *viewss;

@property (strong, nonatomic) UIView *viewColor;

@property (strong, nonatomic) NSString *titleName;
@end
