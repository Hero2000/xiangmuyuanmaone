//
//  XyViewController.h
//  presents
//
//  Created by Xy on 16/1/12.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XyViewController : BaseViewController

@property (copy, nonatomic) NSString *titles;

@property (copy, nonatomic) NSString *newsId;
@end
