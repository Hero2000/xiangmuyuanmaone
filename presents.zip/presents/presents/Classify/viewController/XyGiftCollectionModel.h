//
//  XyGiftCollectionModel.h
//  presents
//
//  Created by Xy on 16/1/9.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import "BaseModel.h"

@interface XyGiftCollectionModel : BaseModel

@property (copy, nonatomic) NSString *icon_url;
@property (copy, nonatomic) NSString *name;

@end
