//
//  XyClassifyCollectionViewCell.h
//  presents
//
//  Created by Xy on 16/1/8.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XyClassifyModel.h"

@interface XyClassifyCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) UIImageView *imageViews;
@property (strong, nonatomic) XyClassifyModel *model;

@end
