//
//  XyClassifyModel.m
//  presents
//
//  Created by Xy on 16/1/8.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import "XyClassifyModel.h"

@implementation XyClassifyModel

@end
