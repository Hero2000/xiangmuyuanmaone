//
//  NZCTextPicTableViewCell.h
//  presents
//
//  Created by dllo on 16/1/9.
//  Copyright © 2016年 dapeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NZCTextPicTableViewCell : UITableViewCell

@property (nonatomic, strong) NSString *urlStr;
@property (nonatomic, strong) UIWebView *webView;

@end
